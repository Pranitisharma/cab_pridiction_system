Data set - https://www.kaggle.com/datasets/ravi72munde/uber-lyft-cab-prices
